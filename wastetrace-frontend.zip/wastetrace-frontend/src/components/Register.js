import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "../styles/Auth.css";

const Register = () => {
  const [vendor, setVendor] = useState({ name: "", mobile: "", password: "" });
  const navigate = useNavigate();

  const handleChange = (e) => {
    setVendor({ ...vendor, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Registration Successful!");
    console.log("Registered Vendor:", vendor);
    navigate("/");
  };

  return (
    <div className="auth-container">
      <h2>Vendor Registration</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Full Name"
          required
          onChange={handleChange}
        />
        <input
          type="tel"
          name="mobile"
          placeholder="Mobile"
          required
          value={vendor.mobile}
          onChange={handleChange}
          pattern="[0-9]{10}"
          title="Enter a 10-digit mobile number"
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          required
          onChange={handleChange}
        />
        <button type="submit">Register</button>
        <p>
          Already registered? <Link to="/">Login</Link>
        </p>
      </form>
    </div>
  );
};

export default Register;
